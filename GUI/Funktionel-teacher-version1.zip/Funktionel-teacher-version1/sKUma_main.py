import sys
from PyQt6 import QtWidgets
from lecture_class import lecture
from TeacherRequestGUI import TeacherRequestGUI

def skuma_main():
    app = QtWidgets.QApplication(sys.argv)
    TR_window = TeacherRequestGUI()
    app.exec()



if __name__ == '__main__':
    skuma_main()