from PyQt6 import QtWidgets, uic
from lecture_class import lecture
import mysql.connector

mydb = mysql.connector.connect(
    host="mysql-db.caprover.diplomportal.dk",
    user="s206026",
    password="oViFSGqnHflEFAA0ETNw1",
    database="s206026")
mycursor = mydb.cursor()
mycursor.execute("SELECT * FROM admincheck")
sqladmin = mycursor.fetchall()

# Loop der tager alle rækker i databasen over lektioner, og putter dem ind på en liste
leclist = []
for lec in range(len(sqladmin)):
    leclist.append(lecture(sqladmin[lec][0], sqladmin[lec][1], sqladmin[lec][2], sqladmin[lec][3]\
                           , sqladmin[lec][4], sqladmin[lec][5]))


class AdminRequestGUI(QtWidgets.QMainWindow):
    """Klasse for selve ændring af lektioner GUI"""

    def __init__(self):  #
        super(AdminRequestGUI, self).__init__()
        uic.loadUi('UI/Admin2.ui', self)
        self.donePushButton.clicked.connect(self.done_push_button_pressed)
        self.acceptPush.clicked.connect(self.accept_button_pressed)
        self.denyPush.clicked.connect(self.deny_button_pressed)
        self.viewPush.clicked.connect(self.view_button_pressed)
        self.show()

        for lect in leclist:
            self.comboLect.addItem(f'course: {lect.get_courseID()}, {lect.get_course()}')


    def done_push_button_pressed(self):
        self.close()

    def deny_button_pressed(self):
        pass

    def accept_button_pressed(self):
        pass

    def view_button_pressed(self):


        mycursor.execute("SELECT * FROM lectures")
        sqllec = mycursor.fetchall()

        chosenRequest = self.comboBox.currentText()




