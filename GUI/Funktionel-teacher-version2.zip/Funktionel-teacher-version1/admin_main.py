import sys
from PyQt6 import QtWidgets
from AdminRequestGUI import AdminRequestGUI

def skuma_main():
    app = QtWidgets.QApplication(sys.argv)
    TR_window = AdminRequestGUI()
    app.exec()

if __name__ == '__main__':
    skuma_main()